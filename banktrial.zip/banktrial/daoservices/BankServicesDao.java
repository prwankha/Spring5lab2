package com.cg.banktrial.daoservices;

import java.util.Map;

import com.cg.banktrial.beans.Customer;

public interface BankServicesDao {
	Customer saveCustomer(Customer customer);
	Customer findCustomer(int customerId);
	boolean deleteCustomer(int customerId);
	Map<Integer,Customer> findAll();
}
