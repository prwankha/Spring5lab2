
package com.cg.banktrial.daoservices;

import java.util.Map;

import com.cg.banktrial.beans.Customer;
import com.cg.banktrial.util.BankUtil;

public class BankServicesDaoImpl implements BankServicesDao {

	@Override
	public Customer saveCustomer(Customer customer) {
		customer.setCustomerId(BankUtil.getCUST_ID_COUNTER());
		BankUtil.customers.put(customer.getCustomerId(), customer);
		return customer;
	}

	@Override
	public Customer findCustomer(int customerId) {
		return BankUtil.customers.get(customerId);
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		BankUtil.customers.remove(customerId);
			return true;
	}

	@Override
	public Map<Integer, Customer> findAll() {
		return BankUtil.customers;
	}

}
