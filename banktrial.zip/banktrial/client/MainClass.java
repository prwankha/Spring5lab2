package com.cg.banktrail.client;

import com.cg.banktrial.services.BankServices;
import com.cg.banktrial.services.BankServicesImpl;

public class MainClass {

	public static void main(String[] args) {
	BankServices bankServices=new BankServicesImpl();
		int id=bankServices.acceptCustomer("fname", "email@gmail.com", "908888888", 501233, 4123, 5000, "Bellary", "karanaatak", 521228);
		System.out.println(id+"\n"+bankServices.balance(id)+"\n"+bankServices.deposit(id, 5000)+"\n"+bankServices.withdraw(id, 25));
		
	}
}