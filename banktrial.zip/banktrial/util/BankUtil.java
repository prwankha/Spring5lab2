package com.cg.banktrial.util;

import java.util.HashMap;
import java.util.Map;
import com.cg.banktrial.beans.Customer;

public class BankUtil {
	 public static int CUST_ID_COUNTER=100;
	 public static Map<Integer,Customer> customers=new HashMap<>();
	 public static int getCUST_ID_COUNTER() {
		return ++CUST_ID_COUNTER;
	}
	public static void setCUST_ID_COUNTER(int cUST_ID_COUNTER) {
		CUST_ID_COUNTER = cUST_ID_COUNTER;
	}
	
	 
}
