package com.cg.banktrial.services;

import com.cg.banktrial.beans.Account;
import com.cg.banktrial.beans.Address;
import com.cg.banktrial.exception.CustomerNotException;

public interface BankServices {
	int acceptCustomer(String firstName, String email, String mobile, int accNumber, int iFSCcode, int balance,
			String city, String state, int pincode);
	
	int withdraw(int customerId,int amount);
	
	int deposit(int customerId,int amount);
	
	int balance(int customerId);
	
	boolean deleteProfile(int customerId) throws CustomerNotException;
	
	boolean validateDetails(String firstname,String email,String mobile);
}
