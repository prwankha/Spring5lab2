package com.cg.banktrial.services;

import com.cg.banktrial.beans.Account;
import com.cg.banktrial.beans.Address;
import com.cg.banktrial.beans.Customer;
import com.cg.banktrial.daoservices.BankServicesDao;
import com.cg.banktrial.daoservices.BankServicesDaoImpl;
import com.cg.banktrial.exception.CustomerNotException;

public class BankServicesImpl implements BankServices{
BankServicesDao bankServicesDao=new BankServicesDaoImpl();
	@Override
	public int acceptCustomer(String firstName, String email, String mobile, int accNumber, int iFSCcode, int balance,
			String city, String state, int pincode) {
		
		Customer customer=new Customer(firstName, email, mobile, new Account(accNumber,iFSCcode,balance), new Address(city, state, pincode));
		bankServicesDao.saveCustomer(customer);
		return customer.getCustomerId();
	}

	@Override
	public int withdraw(int customerId,int amount) {
		Customer customer=bankServicesDao.findCustomer(customerId);
		int balance=customer.getAccount().getBalance()-amount;
		customer.getAccount().setBalance(balance);
		return balance;
	}

	@Override
	public int deposit(int customerId,int amount) {
		Customer customer=bankServicesDao.findCustomer(customerId);
		int balance=customer.getAccount().getBalance()+amount;
		customer.getAccount().setBalance(balance);
		return balance;
	}

	@Override
	public int balance(int customerId) {
		Customer customer=bankServicesDao.findCustomer(customerId);
		return customer.getAccount().getBalance() ;
	}

	@Override
	public boolean deleteProfile(int customerId) throws CustomerNotException {
		if(bankServicesDao.findCustomer(customerId)!=null) {
			bankServicesDao.deleteCustomer(customerId);
			return true;
		}
		else
			throw new CustomerNotException();
	}

	@Override
	public boolean validateDetails(String firstname, String email, String mobile) {
		
		return false;
	}

}
