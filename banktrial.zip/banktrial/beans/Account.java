package com.cg.banktrial.beans;

public class Account {
	private int accNumber,IFSCcode,balance;
	public Account() {}
	public Account(int accNumber, int iFSCcode, int balance) {
		super();
		this.accNumber = accNumber;
		IFSCcode = iFSCcode;
		this.balance = balance;
	}
	
	public int getAccNumber() {
		return accNumber;
	}
	public int getIFSCcode() {
		return IFSCcode;
	}
	public int getBalance() {
		return balance;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public void setIFSCcode(int iFSCcode) {
		IFSCcode = iFSCcode;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accNumber=" + accNumber + ", IFSCcode=" + IFSCcode + ", balance=" + balance + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + IFSCcode;
		result = prime * result + accNumber;
		result = prime * result + balance;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (IFSCcode != other.IFSCcode)
			return false;
		if (accNumber != other.accNumber)
			return false;
		if (balance != other.balance)
			return false;
		return true;
	}
	
}
